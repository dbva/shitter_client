package net.dbva.wrath.module;

import net.dbva.wrath.module.settings.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class Mod {

    private static String name;
    private static String modulename;
    private String displayName;
    private String description;
    private Category category;
    private int key;
    private boolean enabled;

    private final List<Setting> settings = new ArrayList<>();
    protected MinecraftClient mc = MinecraftClient.getInstance();

    public enum Category {
        COMBAT("Combat"), RENDER("Render"), MOVEMENT("Movement"), PLAYER("Player");

        public final String name;

        Category(String name) {
            this.name = name;
        }

    }

    public Mod(String name, String description, Category category) {
        modulename = name;
        this.description = description;
        this.category = category;
        this.setName(modulename);
    }

    public List<Setting> getSettings() {
        return settings;
    }
    public void addSetting(Setting setting) { settings.add(setting); }
    public void addSetting(Setting... settings) {
        for (Setting setting : settings) addSetting(setting);
    }

    public void toggle() {
        this.enabled = !this.enabled;

        if (enabled) {
            onEnable();
        } else onDisable();
    }

    public void onEnable() { mc.player.sendMessage(Text.of("§8[§dWrath§8]§7 toggled " + modulename + "§a on§7."), false); }

    public void onDisable() { mc.player.sendMessage(Text.of("§8[§dWrath§8]§7 toggled " + modulename + "§c off§7."), false); }

    public void onTick() {}

    public String getDisplayName() { return displayName; }

    public String getName() { return modulename; }

    public void setName(String name) { Mod.name = name; }

    public void setDisplayName(String displayName) { this.displayName = displayName; }

    public String getDescription() { return description; }

    public void setDescription(String description) { this.description = description; }

    public Category getCategory() { return category; }

    public void setCategory(Category category) { this.category = category; }

    public int getKey() { return key; }

    public void setKey(int key) { this.key = key; }

    public boolean isEnabled() { return enabled; }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;

        if (enabled) onEnable();
        else onDisable();
    }

    @Override
    public int hashCode() { return Objects.hashCode(name); }
}

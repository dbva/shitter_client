package net.dbva.wrath;

import net.dbva.wrath.module.Mod;
import net.dbva.wrath.module.ModuleManager;
import net.dbva.wrath.ui.screens.clickgui.ClickGUI;
import net.fabricmc.api.ModInitializer;
import net.minecraft.client.MinecraftClient;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.lwjgl.glfw.GLFW;

public class Wrath implements ModInitializer {

	public static final Logger LOGGER = LogManager.getLogger("modid");
	public static final Wrath INSTANCE = new Wrath();

	private final MinecraftClient mc = MinecraftClient.getInstance();

	@Override
	public void onInitialize() { LOGGER.info("Wrath initialization test."); }

	public void onKeyPress(int key, int action) {
		if (action == GLFW.GLFW_PRESS) {
			for (Mod module : ModuleManager.INSTANCE.getModules()) {
				if (key == module.getKey()) module.toggle();
			}

			if (key == GLFW.GLFW_KEY_RIGHT_CONTROL) {
				if (mc.currentScreen == null) mc.setScreen(ClickGUI.INSTANCE);
			}
		}
	}

	public void onTick() {
		if (mc.player != null) {
			for (Mod module : ModuleManager.INSTANCE.getEnabledModules()) {
				module.onTick();
			}
		}
	}
}

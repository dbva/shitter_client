package net.dbva.wrath.ui;

import net.dbva.wrath.module.Mod;
import net.dbva.wrath.module.ModuleManager;
import net.dbva.wrath.ui.screens.clickgui.ClickGUI;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.MatrixStack;

import java.awt.*;
import java.util.List;
import java.util.Comparator;

public class Hud {

    public static final int RIGHT_SCREEN_PADDING = 4;
    public static final int TOP_SCREEN_PADDING = 10;
    private static MinecraftClient mc = MinecraftClient.getInstance();

    public static void render(MatrixStack matrices, float TickDelta) {
        RenderArrayList(matrices);
    }

    public static int rainbow(int delay) {
        double rainbowState = Math.ceil((System.currentTimeMillis() + delay) / 20.0);
        rainbowState %= 360;
        return Color.getHSBColor((float) (rainbowState / 360.0f), 0.5f, 1f).getRGB();
    }


    public static void RenderArrayList(MatrixStack matrices) {
        int index = 0;
        int sWidth = mc.getWindow().getScaledWidth();
        int sHeight = mc.getWindow().getScaledHeight();

        List<Mod> enabled = ModuleManager.INSTANCE.getEnabledModules();

        enabled.sort(Comparator.comparingInt(m -> mc.textRenderer.getWidth(((Mod)m).getDisplayName())).reversed());

        if (mc.currentScreen == ClickGUI.INSTANCE) return;
        for (Mod mod : enabled) {
            mc.textRenderer.drawWithShadow(matrices, mod.getDisplayName(),  (sWidth - RIGHT_SCREEN_PADDING) - mc.textRenderer.getWidth(mod.getDisplayName()), TOP_SCREEN_PADDING + (index *mc.textRenderer.fontHeight), rainbow(1));
            index++;
        }
    }
}